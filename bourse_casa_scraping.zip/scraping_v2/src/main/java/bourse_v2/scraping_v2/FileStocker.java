package bourse_v2.scraping_v2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;

public class FileStocker {
	private 		Date date=new GregorianCalendar().getTime();
	
	private 	   String name;
	private static String path;
	 
	private static FileWriter data=null;
	private static BufferedWriter buff=null;
	
	
	public FileStocker(String path, String name) throws IOException{
	
	this.name=name;
	this.path=path;
	this.data=new FileWriter(path+"/"+name+".txt", false);
	this.buff=new BufferedWriter(data);
	}
	////////////////////////////////////////////////////////////////////
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	public static FileWriter getData() {
		return data;
	}

	public static void setData(FileWriter data) {
		FileStocker.data = data;
	}

	public static BufferedWriter getBuff() {
		return buff;
	}

	public static void setBuff(BufferedWriter buff) {
		FileStocker.buff = buff;
	}
	
	/////////////////////////////////////////////////////////////////////
	public boolean start(String towrite) throws IOException{
		try{
		
			this.buff.write(towrite);
		
		}catch(IOException e){
			e.printStackTrace();
			return false;
		} 
		
		return true;
	
	} 
	 public void stop() throws IOException{
		 
		 this.buff.close();
		 
	 	}
	
}