package bourse_v2.scraping_v2;
import java.util.Date;
import java.util.GregorianCalendar;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class App 
{	 
	private static String file;
	
	
	public static void main( String[] args )throws Exception
    {
		Date date=new GregorianCalendar().getTime();
	    file=new String();
		final Document bourse_cours = Jsoup.connect("http://www.casablanca-bourse.com/bourseweb/Activite-marche.aspx?Cat=22&IdLink=297").get();
		   
	for(int j=1;j<8;j=j+2)
	{
		String table_ietrator_selector ="#ctl00 > table > tbody > tr:nth-child(2) > td:nth-child(2) > table:nth-child(9) > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td > table > tbody > tr > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td:nth-child(1) > table:nth-child("+j+")";
		
		Elements table1_iterator=bourse_cours.select(table_ietrator_selector);
		
		for(Element parser_tables: table1_iterator)
		
		{	Element tr1_td=parser_tables.child(0).child(0);
			//title to get
			System.out.println(tr1_td.child(0).text());
			
			Element tr2=tr1_td.nextElementSibling();
			Elements rows=tr2.child(0).child(0).child(0).children();
			
			String rows_sticker="";
			for(Element tr_parser:rows){
				
				Elements tds=tr_parser.children();
				String sticker="";
				for(Element td_parser: tds){
					
					sticker=sticker+" | "+td_parser.text();
				
				
				}
				rows_sticker=rows_sticker+sticker+"\n";
				
				System.out.println(rows_sticker+"\n");
				file=file+rows_sticker+"\n";
			}
			
		
		} 
	} 
		
     
        
		
		Elements cible_title=bourse_cours.select("#ActiviteMarche1_PnlIndiceSect1 > table > tbody > tr:nth-child(1) > td");
        
        String title=cible_title.get(0).text() ;     
        
        System.out.println(title+"\n");
        file=file+title+"\n";
        
        
       for(int i=1; i<26;i++){ 
    	
    	   Elements trs =bourse_cours.select("#arial11bleu > tbody > tr:nth-child("+i+")");
    	 
        	
    	   for(Element tr:trs){
        		
        		Elements tds=tr.children();
        		
        		String assembler=" ";
        		
        		for(Element td:tds){
        			
        			assembler=assembler+"  |  "+td.text();
        			
        		
        		}
        	
        	System.out.println(assembler);	
        	file=file+assembler+"\n ";
        	}
       
        
    	 
       }
        
       
       	
       String newLine = System.getProperty("line.separator");
       
       for(int i=2;i<5;i=i+2)	
        {   Elements right_table1_title=bourse_cours.select("#ActiviteMarche1_PnlIndiceSect2 > table:nth-child("+i+") > tbody > tr:nth-child(1)");
          
          
          
          System.out.println(right_table1_title.first().text()+"\n");
      	file=file+right_table1_title.first().text()+"\n ";

          Elements right_table_tr2_trs=bourse_cours.select("#ActiviteMarche1_PnlIndiceSect2 > table:nth-child("+i+") > tbody > tr:nth-child(2) > td > table > tbody");
          
          String trAssembler=" ";
          
          for(Element tr:right_table_tr2_trs ){
          	
          	Elements tds=tr.children();
          	String sticker=" ";
          	
          	for(Element td:tds){
          		
          		sticker=sticker+" | "+td.text()+" | "+"\n";
          		
          	}
          	
          	trAssembler=trAssembler+" "+sticker;
          }
          System.out.println(trAssembler+newLine);
          file=file+trAssembler+newLine;
      }   
       	
   		Elements right_table3_title=bourse_cours.select("#ActiviteMarche1_PnlIndiceSect2 > table:nth-child(6) > tbody > tr:nth-child(1)");
       	
       	System.out.println(right_table3_title.first().text()+"\n");
       	file=file+right_table3_title.first().text()+"\n";
       	
       	Elements right_table3_trs=bourse_cours.select("#ActiviteMarche1_PnlIndiceSect2 > table:nth-child(6) > tbody > tr:nth-child(4) > td > table > tbody");
       	String trAssembler3="";
       	
       	for(Element tr:right_table3_trs){
       		
       		Elements tds =tr.children();
       		String sticker=" ";
       		for(Element td:tds){
       			
       			sticker=sticker+" | "+td.text()+" | "+"\n"; 
           		

       		}
       		trAssembler3=trAssembler3+" "+sticker;
       		
       		
       	}
   		System.out.println(trAssembler3+newLine);
   		file=file+trAssembler3+newLine;
       	
   		FileStocker stock=new FileStocker("/home/youssef/workspace/scraping_v2/data stock",date.toString());
       	
   		boolean check=stock.start(file);
       	if(check==true)
       	{
       		System.out.println("succeded");
       		stock.stop();
       	}
       	else System.out.println(" didn't succeded");
       	
       	
       	
       	
       
        
       	try{
 	        Thread.sleep( 17*60*1000 );
 	    }
 	    catch( InterruptedException e ){
 	       
 	        e.printStackTrace();
 	    }
       	
	     
	  
        
        
        
        
        
        
        
    }
	
	
	public static String getFile() {
		return file;
	}

	public static void setFile(String file) {
		App.file = file;
	}

	
	
	
	
	
	    
                
       
    
}

